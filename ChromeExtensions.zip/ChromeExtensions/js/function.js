vdderr = document.querySelector('video');
